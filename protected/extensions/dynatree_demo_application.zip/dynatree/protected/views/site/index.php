<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>


<div class="form"> 

    <?php $form=$this->beginWidget('CActiveForm', array(
        'id'=>'product-form',
        'enableAjaxValidation'=>false,
        'htmlOptions'=>array('enctype'=>'multipart/form-data')
    )); ?>
    <?php echo $form->hiddenField($model,'id'); ?>
     
    <?php $this->widget('ext.dynatree.DynaTree',array(
        'attribute'=>CHtml::activeName($model,'categories'),
        'data'=>Category::model()->getCategoryTree('tree'),
        'selection'=>CategoryProduct::getIds('category_id','product_id',$model->id),
    )); ?>
    
    <div class="left row">
        <?php echo CHtml::submitButton('Save'); ?>
    </div>
    
<?php $this->endWidget(); ?>

</div><!-- form -->
